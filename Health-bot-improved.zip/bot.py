import os
import sys
import logging
import psycopg2
import psycopg2.extras
import google.generativeai as genai
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.constants import ChatAction
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ContextTypes, ConversationHandler
)

# ─── Логирование ───────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, stream=sys.stdout,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

# ─── Переменные окружения ───────────────────────────────────────────────────────
TOKEN = os.environ.get("TELEGRAM_TOKEN")
GEMINI_KEY = os.environ.get("GEMINI_API_KEY")
DATABASE_URL = os.environ.get("DATABASE_URL")  # PostgreSQL URL (Railway/Render)

# ─── Шаги анкеты ───────────────────────────────────────────────────────────────
GENDER, AGE, DISEASES, MEDS = range(4)

# ─── Максимум сообщений в истории на пользователя ──────────────────────────────
MAX_HISTORY = 10


# ══════════════════════════════════════════════════════════════════════════════
# 1. ИИ — автоподбор модели
# ══════════════════════════════════════════════════════════════════════════════

def setup_ai():
    try:
        genai.configure(api_key=GEMINI_KEY)
        models = [
            m.name for m in genai.list_models()
            if "generateContent" in m.supported_generation_methods
        ]
        priority = [
            "models/gemini-1.5-flash",
            "models/gemini-1.5-flash-latest",
            "models/gemini-pro",
        ]
        for p in priority:
            if p in models:
                logger.info(f"Выбрана модель: {p}")
                return genai.GenerativeModel(p)
        if models:
            logger.info(f"Используем первую доступную модель: {models[0]}")
            return genai.GenerativeModel(models[0])
        logger.error("Нет доступных моделей Gemini")
        return None
    except Exception as e:
        logger.error(f"Ошибка инициализации ИИ: {e}")
        return None


ai_model = setup_ai()


# ══════════════════════════════════════════════════════════════════════════════
# 2. База данных (PostgreSQL — данные не теряются при рестарте)
# ══════════════════════════════════════════════════════════════════════════════

def get_conn():
    """Возвращает соединение с PostgreSQL."""
    if not DATABASE_URL:
        raise RuntimeError("Переменная DATABASE_URL не задана!")
    return psycopg2.connect(DATABASE_URL, cursor_factory=psycopg2.extras.RealDictCursor)


def init_db():
    """Создаёт таблицы при первом запуске."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id      BIGINT PRIMARY KEY,
                        gender  TEXT,
                        age     INTEGER,
                        diseases TEXT,
                        meds    TEXT
                    )
                """)
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS history (
                        id      SERIAL PRIMARY KEY,
                        user_id BIGINT NOT NULL,
                        role    TEXT NOT NULL,
                        message TEXT NOT NULL,
                        created_at TIMESTAMPTZ DEFAULT NOW()
                    )
                """)
        logger.info("База данных инициализирована")
    except Exception as e:
        logger.error(f"Ошибка инициализации БД: {e}")
        raise


def get_patient_context(uid: int) -> str:
    """Возвращает строку с данными пациента для системного промпта."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM users WHERE id = %s", (uid,))
                row = cur.fetchone()
        if row:
            return (
                f"Пол: {row['gender']}, возраст: {row['age']}, "
                f"хронические заболевания: {row['diseases']}, "
                f"принимаемые лекарства: {row['meds']}."
            )
    except Exception as e:
        logger.error(f"Ошибка чтения данных пациента (uid={uid}): {e}")
    return "Данные анкеты отсутствуют. Напомни пользователю заполнить её командой /anketa."


def save_patient(uid: int, gender: str, age: int, diseases: str, meds: str):
    """Сохраняет или обновляет данные пациента."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO users (id, gender, age, diseases, meds)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE
                SET gender=%s, age=%s, diseases=%s, meds=%s
            """, (uid, gender, age, diseases, meds,
                  gender, age, diseases, meds))


# ── История переписки ──────────────────────────────────────────────────────────

def load_history(uid: int) -> list[dict]:
    """Загружает последние MAX_HISTORY сообщений пользователя."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT role, message FROM history
                    WHERE user_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (uid, MAX_HISTORY))
                rows = cur.fetchall()
        return list(reversed(rows))
    except Exception as e:
        logger.error(f"Ошибка загрузки истории (uid={uid}): {e}")
        return []


def append_history(uid: int, role: str, message: str):
    """Добавляет сообщение в историю."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO history (user_id, role, message) VALUES (%s, %s, %s)",
                    (uid, role, message)
                )
    except Exception as e:
        logger.error(f"Ошибка записи истории (uid={uid}): {e}")


def clear_history(uid: int):
    """Очищает историю пользователя."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM history WHERE user_id = %s", (uid,))
    except Exception as e:
        logger.error(f"Ошибка очистки истории (uid={uid}): {e}")


# ══════════════════════════════════════════════════════════════════════════════
# 3. Команды
# ══════════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.effective_user.first_name or "друг"
    await update.message.reply_text(
        f"👋 Привет, {name}!\n\n"
        "Я — твой персональный медицинский ассистент на базе ИИ.\n\n"
        "Что я умею:\n"
        "• Отвечать на медицинские вопросы\n"
        "• Анализировать фото результатов анализов\n"
        "• Учитывать твои личные данные и препараты\n"
        "• Помнить контекст нашего разговора\n\n"
        "Команды:\n"
        "/anketa — заполнить личную анкету\n"
        "/mydata — посмотреть свои данные\n"
        "/reset — очистить историю разговора\n"
        "/help — помощь\n\n"
        "⚠️ Я не заменяю врача. При серьёзных симптомах обратись к специалисту."
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ Как пользоваться:\n\n"
        "1. Заполни анкету /anketa — я буду учитывать твои данные\n"
        "2. Задавай любые медицинские вопросы текстом\n"
        "3. Отправь фото анализов — я помогу разобраться\n"
        "4. /reset — начать разговор с чистого листа\n\n"
        "⚠️ Я — ИИ-ассистент, а не врач. Мои ответы носят информационный характер."
    )


async def cmd_mydata(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ctx = get_patient_context(uid)
    await update.message.reply_text(f"📋 Твои данные:\n{ctx}")


async def cmd_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    clear_history(update.effective_user.id)
    await update.message.reply_text("🗑 История разговора очищена. Начинаем заново!")


# ══════════════════════════════════════════════════════════════════════════════
# 4. Анкета — пошаговый диалог (ConversationHandler)
# ══════════════════════════════════════════════════════════════════════════════

async def anketa_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [["Мужской", "Женский"]]
    await update.message.reply_text(
        "📝 Заполним анкету! Это займёт меньше минуты.\n\nШаг 1/4 — Укажи пол:",
        reply_markup=ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    )
    return GENDER


async def anketa_gender(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if text not in ("Мужской", "Женский"):
        await update.message.reply_text("Пожалуйста, выбери один из вариантов: Мужской / Женский")
        return GENDER
    context.user_data["gender"] = text
    await update.message.reply_text(
        "Шаг 2/4 — Введи возраст (например: 28):",
        reply_markup=ReplyKeyboardRemove()
    )
    return AGE


async def anketa_age(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit() or not (1 <= int(text) <= 120):
        await update.message.reply_text("Введи корректный возраст (число от 1 до 120):")
        return AGE
    context.user_data["age"] = int(text)
    await update.message.reply_text(
        "Шаг 3/4 — Укажи хронические заболевания через запятую.\n"
        "Если их нет — напиши «Нет»:"
    )
    return DISEASES


async def anketa_diseases(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["diseases"] = update.message.text.strip()
    await update.message.reply_text(
        "Шаг 4/4 — Какие лекарства принимаешь постоянно? Через запятую.\n"
        "Если не принимаешь — напиши «Нет»:"
    )
    return MEDS


async def anketa_meds(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    meds = update.message.text.strip()
    d = context.user_data
    try:
        save_patient(uid, d["gender"], d["age"], d["diseases"], meds)
        await update.message.reply_text(
            "✅ Анкета сохранена! Теперь я буду учитывать твои данные в ответах.\n\n"
            f"📋 Сохранено:\n"
            f"• Пол: {d['gender']}\n"
            f"• Возраст: {d['age']}\n"
            f"• Заболевания: {d['diseases']}\n"
            f"• Лекарства: {meds}"
        )
    except Exception as e:
        logger.error(f"Ошибка сохранения анкеты (uid={uid}): {e}")
        await update.message.reply_text("⚠️ Не удалось сохранить анкету. Попробуй позже.")
    return ConversationHandler.END


async def anketa_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Заполнение анкеты отменено.", reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END


# ══════════════════════════════════════════════════════════════════════════════
# 5. Основной обработчик сообщений (текст + фото) с памятью разговора
# ══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = (
    "Ты — персональный медицинский ассистент. Общаешься на русском языке. "
    "Отвечай чётко, по существу, без лишней воды. "
    "Если вопрос не связан с медициной или здоровьем, вежливо об этом скажи. "
    "⚠️ Всегда напоминай, что твои ответы носят информационный характер и не заменяют визита к врачу."
)


async def handle_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not ai_model:
        await update.message.reply_text("⚠️ ИИ недоступен. Попробуй позже.")
        return

    uid = update.effective_user.id
    user_text = update.message.text or update.message.caption or "Проанализируй это изображение"

    await update.message.reply_chat_action(ChatAction.TYPING)

    # Формируем историю для контекста
    history = load_history(uid)
    history_text = ""
    if history:
        history_text = "\n\nИСТОРИЯ ДИАЛОГА (последние сообщения):\n"
        for msg in history:
            role_label = "Пользователь" if msg["role"] == "user" else "Ассистент"
            history_text += f"{role_label}: {msg['message']}\n"

    content = [
        SYSTEM_PROMPT + "\n",
        f"ДАННЫЕ ПАЦИЕНТА: {get_patient_context(uid)}\n",
        history_text,
        f"\nТЕКУЩИЙ ЗАПРОС: {user_text}",
    ]

    # Если прислали фото
    if update.message.photo:
        try:
            file = await update.message.photo[-1].get_file()
            img_bytes = await file.download_as_bytearray()
            content.append({"mime_type": "image/jpeg", "data": bytes(img_bytes)})
        except Exception as e:
            logger.error(f"Ошибка загрузки фото (uid={uid}): {e}")
            await update.message.reply_text("⚠️ Не удалось загрузить фото. Попробуй ещё раз.")
            return

    try:
        response = ai_model.generate_content(content)
        answer = response.text

        # Сохраняем в историю
        append_history(uid, "user", user_text)
        append_history(uid, "assistant", answer[:1000])  # обрезаем длинные ответы для хранения

        # Отправляем ответ (с учётом лимита Telegram 4096 символов)
        for i in range(0, len(answer), 4000):
            await update.message.reply_text(answer[i:i + 4000])

    except Exception as e:
        logger.error(f"Ошибка генерации ответа (uid={uid}): {e}")
        await update.message.reply_text(f"⚠️ Ошибка при обращении к ИИ: {str(e)}")


# ══════════════════════════════════════════════════════════════════════════════
# 6. Запуск
# ══════════════════════════════════════════════════════════════════════════════

def main():
    if not TOKEN:
        logger.critical("TELEGRAM_TOKEN не задан!")
        sys.exit(1)
    if not GEMINI_KEY:
        logger.critical("GEMINI_API_KEY не задан!")
        sys.exit(1)
    if not DATABASE_URL:
        logger.critical("DATABASE_URL не задан!")
        sys.exit(1)

    init_db()

    app = Application.builder().token(TOKEN).build()

    # Пошаговая анкета
    anketa_handler = ConversationHandler(
        entry_points=[CommandHandler("anketa", anketa_start)],
        states={
            GENDER:   [MessageHandler(filters.TEXT & ~filters.COMMAND, anketa_gender)],
            AGE:      [MessageHandler(filters.TEXT & ~filters.COMMAND, anketa_age)],
            DISEASES: [MessageHandler(filters.TEXT & ~filters.COMMAND, anketa_diseases)],
            MEDS:     [MessageHandler(filters.TEXT & ~filters.COMMAND, anketa_meds)],
        },
        fallbacks=[CommandHandler("cancel", anketa_cancel)],
    )

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("mydata", cmd_mydata))
    app.add_handler(CommandHandler("reset", cmd_reset))
    app.add_handler(anketa_handler)
    app.add_handler(MessageHandler(filters.TEXT | filters.PHOTO, handle_all))

    logger.info("Бот запущен")
    app.run_polling()


if __name__ == "__main__":
    main()
